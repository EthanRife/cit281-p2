/*
    CIT 281 Project 2
    Name: Ethan Rife
*/
// Returns a random number between min (inclusive) and max (exclusive)
function getRandomInteger(minLength, maxLength) {
    return Math.floor(Math.random() * (maxLength - minLength) + minLength);
}

// The function getRandomLetter returns a single random letter from the constant string alphabet
function getRandomLetter() {
    let alphabet = "abcdefghijklmnopqrstuvwxyz".split("");
    return alphabet[getRandomInteger(1,alphabet.length-1)];
}

// The function getRandomString recieves a minimum length and maximum length as parameters, it returns a random length string of random letters that is between the range of the parameters
function getRandomString(minLength, maxLength) {
    let result = "";
    for (let i = 0; i < getRandomInteger(minLength, maxLength); i++) {
        result += getRandomLetter();
}
return result;
}

//The function takes any string breaks it into an array at every character, sorts the array alphabetically, joins the array back into a string and then returns the new string
function getSortedString(string) {let arr = string.split(''); let sorted = arr.sort(); let stringy = sorted.join(''); return stringy}

//console.log(getSortedString("string"))
console.log(getRandomString(10,20));